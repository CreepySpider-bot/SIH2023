// 

import React, { useState, useEffect } from 'react';
import './LogsTable.css'; // Import your CSS file for styling

var counter = 0;
const LogsTable = ({ logs }) => {
  return (
    <div className="logs-table-container">
      <table>
        <thead>
          <tr>
            <th>Timestamp</th>
            <th>Source</th>
            <th>Action</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log, index) => (
            <tr key={index}>
              <td>{log.timestamp}</td>
              <td>{log.source}</td>
              <td>{log.action}</td>
              {
              
              log.details && (log.details.includes("Malicious") || log.details.includes("DGA"))?
              <td style={{backgroundColor:"red"}}>{log.details}</td>:
              <td>{log.details}</td>
                }
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const Logs = ({ onValueChange, onMalChange }) => {
  const filePath = 'logfile2.log';
  const [logContent, setLogContent] = useState([]);

  useEffect(() => {
    const fetchLogFile = async () => {
      try {
        const response = await fetch(filePath);
        const content = await response.text();
        const logsArray = parseLogData(content);
        setLogContent(logsArray);
        onValueChange(logsArray.length);

      } catch (error) {
        console.error('Error fetching log file:', error);
      }
    };

    fetchLogFile();
  }, []);

  const parseLogData = (logText) => {
    // Implement logic to parse the log text and return an array of log objects
    // Example parsing logic (adjust as needed):



    return logText.split('\n').map((line) => {
      const [timestamp, source, action, details] = line.split(' - ');
      if (details && details.includes("Malicious")) {
        // Increment the global counter variable
        counter += 1;
        // Call the onMalChange callback with the updated counter value
        onMalChange(counter);
      }
      return { timestamp, source, action, details };
    });
  };

  return (
    <div>
      <h1>Log File Content</h1>
      <LogsTable logs={logContent} />
    </div>
  );
};

export default Logs;
