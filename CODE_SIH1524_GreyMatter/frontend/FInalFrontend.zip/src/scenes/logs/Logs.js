// 

import React, { useState, useEffect } from 'react';
import './LogsTable.css'; // Import your CSS file for styling

const LogsTable = ({ logs }) => {
  return (
    <div className="logs-table-container">
      <table>
        <thead>
          <tr>
            <th>Timestamp</th>
            <th>Source</th>
            <th>Action</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log, index) => (
            <tr key={index}>
              <td>{log.timestamp}</td>
              <td>{log.source}</td>
              <td>{log.action}</td>
              <td>{log.details}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const Logs = () => {
  const filePath = 'logfile.log';
  const [logContent, setLogContent] = useState([]);

  useEffect(() => {
    const fetchLogFile = async () => {
      try {
        const response = await fetch(filePath);
        const content = await response.text();
        const logsArray = parseLogData(content);
        setLogContent(logsArray);
      } catch (error) {
        console.error('Error fetching log file:', error);
      }
    };

    fetchLogFile();
  }, []);

  const parseLogData = (logText) => {
    // Implement logic to parse the log text and return an array of log objects
    // Example parsing logic (adjust as needed):
    return logText.split('\n').map((line) => {
      const [timestamp, source, action, details] = line.split(' - ');
      return { timestamp, source, action, details };
    });
  };

  return (
    <div>
      <h1>Log File Content</h1>
      <LogsTable logs={logContent} />
    </div>
  );
};

export default Logs;
