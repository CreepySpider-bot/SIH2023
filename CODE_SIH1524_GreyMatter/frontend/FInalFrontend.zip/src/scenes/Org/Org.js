import { Box } from '@mui/material';
import React from 'react'

function Organisation() {
  return (
    <Box m='20px'> 
      <h1>ORGANISATION</h1>
    </Box>
  )
}

export default Organisation;
